# Projeto Miaupedia - Consumo de API e JQuery
Repositório para o projeto de estudo em grupo de Consumo de API e JQuery do curso +Devs2Blu
